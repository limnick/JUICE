{
"frames": {
	"guns_01.png": {
		"frame": {"x":158, "y":121, "w":40, "h":31},
		"spriteSourceSize": {"x":0,"y":0,"w":40,"h":31},
		"sourceSize": {"w":40,"h":31}
	},
	"guns_02.png": {
		"frame": {"x":158, "y":89, "w":51, "h":31},
		"spriteSourceSize": {"x":0,"y":0,"w":51,"h":31},
		"sourceSize": {"w":51,"h":31}
	},
	"guns_03.png": {
		"frame": {"x":158, "y":41, "w":52, "h":47},
		"spriteSourceSize": {"x":0,"y":0,"w":52,"h":47},
		"sourceSize": {"w":52,"h":47}
	},
	"guns_04.png": {
		"frame": {"x":0, "y":120, "w":79, "h":51},
		"spriteSourceSize": {"x":0,"y":0,"w":79,"h":51},
		"sourceSize": {"w":79,"h":51}
	},
	"guns_05.png": {
		"frame": {"x":158, "y":182, "w":30, "h":28},
		"spriteSourceSize": {"x":0,"y":0,"w":30,"h":28},
		"sourceSize": {"w":30,"h":28}
	},
	"guns_06.png": {
		"frame": {"x":81, "y":77, "w":76, "h":37},
		"spriteSourceSize": {"x":0,"y":0,"w":76,"h":37},
		"sourceSize": {"w":76,"h":37}
	},
	"guns_07.png": {
		"frame": {"x":80, "y":163, "w":77, "h":33},
		"spriteSourceSize": {"x":0,"y":0,"w":77,"h":33},
		"sourceSize": {"w":77,"h":33}
	},
	"guns_08.png": {
		"frame": {"x":0, "y":86, "w":80, "h":33},
		"spriteSourceSize": {"x":0,"y":0,"w":80,"h":33},
		"sourceSize": {"w":80,"h":33}
	},
	"guns_09.png": {
		"frame": {"x":158, "y":153, "w":32, "h":28},
		"spriteSourceSize": {"x":0,"y":0,"w":32,"h":28},
		"sourceSize": {"w":32,"h":28}
	},
	"guns_10.png": {
		"frame": {"x":95, "y":0, "w":65, "h":40},
		"spriteSourceSize": {"x":0,"y":0,"w":65,"h":40},
		"sourceSize": {"w":65,"h":40}
	},
	"guns_11.png": {
		"frame": {"x":80, "y":120, "w":77, "h":42},
		"spriteSourceSize": {"x":0,"y":0,"w":77,"h":42},
		"sourceSize": {"w":77,"h":42}
	},
	"guns_12.png": {
		"frame": {"x":0, "y":48, "w":80, "h":37},
		"spriteSourceSize": {"x":0,"y":0,"w":80,"h":37},
		"sourceSize": {"w":80,"h":37}
	},
	"guns_13.png": {
		"frame": {"x":161, "y":0, "w":29, "h":28},
		"spriteSourceSize": {"x":0,"y":0,"w":29,"h":28},
		"sourceSize": {"w":29,"h":28}
	},
	"guns_14.png": {
		"frame": {"x":81, "y":48, "w":76, "h":28},
		"spriteSourceSize": {"x":0,"y":0,"w":76,"h":28},
		"sourceSize": {"w":76,"h":28}
	},
	"guns_15.png": {
		"frame": {"x":0, "y":172, "w":79, "h":40},
		"spriteSourceSize": {"x":0,"y":0,"w":79,"h":40},
		"sourceSize": {"w":79,"h":40}
	},
	"guns_16.png": {
		"frame": {"x":0, "y":0, "w":94, "h":47},
		"spriteSourceSize": {"x":0,"y":0,"w":94,"h":47},
		"sourceSize": {"w":94,"h":47}
	}

},
"meta": {
	"image": "sprites.png",
	"size": {"w": 211, "h": 213},
	"scale": "1"
}
}